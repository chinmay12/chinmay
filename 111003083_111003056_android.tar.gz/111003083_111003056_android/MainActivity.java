package com.example.message;

import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class MainActivity extends Activity {
	private TextToSpeech mTts;
	Intent checkIntent = new Intent();
	private int MY_DATA_CHECK_CODE = 0;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ListView lViewSMS = (ListView) findViewById(R.id.listViewSMS);

		if (fetchInbox() != null) {
 			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_list_item_1, fetchInbox());
			lViewSMS.setAdapter(adapter);

		}

		lViewSMS.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				String selectedText = (String) parent
						.getItemAtPosition(position);
				mTts.speak(selectedText, TextToSpeech.QUEUE_ADD, null);

			}
		});
		Intent checkIntent = new Intent();
		checkIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
		startActivityForResult(checkIntent, MY_DATA_CHECK_CODE);
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == MY_DATA_CHECK_CODE) {
			if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
				// success, create the TTS instance
				mTts = new TextToSpeech(this, new OnInitListener() {
					@Override
					public void onInit(int status) {
						if (status == TextToSpeech.SUCCESS) {
							int result = mTts.setLanguage(Locale.UK);
							Toast.makeText(MainActivity.this,
									"Text-To-Speech engine is initialized", Toast.LENGTH_LONG)
									.show();
						} else if (status == TextToSpeech.ERROR) {
							Toast.makeText(MainActivity.this,
									"Error occurred while initializing Text-To-Speech engine",
									Toast.LENGTH_LONG).show();
						}
					}
				});
			} else {
				// missing data, install it
				Intent installIntent = new Intent();
				installIntent
						.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
				startActivity(installIntent);
			}
		}

	}


	public ArrayList<String> fetchInbox() {
		ArrayList<String> sms = new ArrayList<String>();

		Uri uriSms = Uri.parse("content://sms/inbox");
		Cursor cursor = getContentResolver().query(uriSms,
				new String[] { "_id", "address", "date", "body" }, null, null,
				null);

		cursor.moveToFirst();
		while (cursor.moveToNext()) {
			String address = cursor.getString(1);
			String body = cursor.getString(3);

			System.out.println("S M S from" + address);
			System.out.println("and S M S is----->" + body);

			sms.add("S M S from" + address + "and S M S is-----> " + body);
		}
		return sms;

	}
}